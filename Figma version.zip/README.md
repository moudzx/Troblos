
  # Tripoli Lebanon Website

  This is a code bundle for Tripoli Lebanon Website. The original project is available at https://www.figma.com/design/YvmOD2zHffmV2VJrqkuNkP/Tripoli-Lebanon-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  