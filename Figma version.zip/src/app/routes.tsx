import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { Home } from "./components/Home";
import { Food } from "./components/Food";
import { History } from "./components/History";
import { Gallery } from "./components/Gallery";
import { Places } from "./components/Places";
import { Facts } from "./components/Facts";
import { Booking } from "./components/Booking";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "food", Component: Food },
      { path: "history", Component: History },
      { path: "gallery", Component: Gallery },
      { path: "places", Component: Places },
      { path: "facts", Component: Facts },
      { path: "booking", Component: Booking },
    ],
  },
]);
