import { motion } from 'motion/react';
import {
  Building2, Cake, MapPin, Users, BookOpen, Trophy,
  Landmark, Ship, Heart, Sparkles
} from 'lucide-react';

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 28 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] },
});

const facts = [
  { icon: Building2, title: 'أكثر من 160 معلم تاريخي', description: 'تحتوي طرابلس على أكبر تجمع للعمارة المملوكية في لبنان، مع أكثر من 160 معلماً تاريخياً مصنفاً', category: 'تاريخ' },
  { icon: Cake, title: 'عاصمة الحلويات', description: 'تُلقب طرابلس بعاصمة الحلويات في العالم العربي، حيث يوجد أكثر من 80 محل حلويات تقليدي', category: 'ثقافة' },
  { icon: MapPin, title: 'ثاني أكبر مدينة لبنانية', description: 'طرابلس هي ثاني أكبر مدينة في لبنان بعد بيروت، وعاصمة محافظة الشمال', category: 'جغرافيا' },
  { icon: Users, title: 'مدينة الطلاب', description: 'تضم طرابلس عدة جامعات ومعاهد، وتُعرف بأنها مدينة العلم والطلاب في الشمال اللبناني', category: 'تعليم' },
  { icon: BookOpen, title: 'مكتبة تاريخية', description: 'تحوي طرابلس مكتبات تاريخية تعود للعصر المملوكي، بعضها ما زال يحتفظ بمخطوطات نادرة', category: 'تاريخ' },
  { icon: Trophy, title: 'أقدم صابون في العالم', description: 'تشتهر طرابلس بصناعة الصابون البلدي منذ مئات السنين، وما زالت بعض المصابن التقليدية تعمل', category: 'صناعة' },
  { icon: Landmark, title: 'قلعة ضخمة', description: 'قلعة طرابلس هي واحدة من أكبر القلاع الصليبية في المنطقة، يمكن رؤيتها من كل المدينة', category: 'معالم' },
  { icon: Ship, title: 'ميناء فينيقي', description: 'كانت طرابلس ميناءً تجارياً مهماً للفينيقيين منذ أكثر من 3000 عام', category: 'تاريخ' },
  { icon: Heart, title: 'مدينة التسامح', description: 'تعايشت في طرابلس عبر القرون مختلف الديانات والثقافات في تناغم وسلام حقيقي', category: 'ثقافة' },
  { icon: Sparkles, title: 'لؤلؤة الشمال', description: 'تُلقب طرابلس بـ"عروس الشمال" و"لؤلؤة الشمال اللبناني" لجمالها وأهميتها التاريخية', category: 'ألقاب' },
];

const records = [
  { title: 'أقدم سوق ذهب', description: 'يُعتبر سوق الذهب في طرابلس من أقدم أسواق الذهب المستمرة في المنطقة' },
  { title: 'أكبر حمامات عامة', description: 'تضم المدينة أكثر من 12 حماماً تاريخياً، بعضها يعود للعصر المملوكي' },
  { title: 'مئذنة فريدة', description: 'تتميز مآذن طرابلس بطراز معماري فريد يجمع بين الأساليب المملوكية والعثمانية' },
  { title: 'خانات تاريخية', description: 'يوجد في المدينة أكثر من 20 خاناً تاريخياً كانت تستخدم لراحة التجار والمسافرين' },
];

const didYouKnow = [
  'كانت طرابلس عاصمة للثقافة الإسلامية في عام 2000',
  'يعود اسم "طرابلس" إلى الكلمة اليونانية التي تعني "المدن الثلاث"',
  'تُصنع في طرابلس أفضل أنواع البقلاوة في العالم حسب تصنيفات عالمية',
  'المدينة القديمة في طرابلس مرشحة لقائمة التراث العالمي لليونسكو',
  'تشتهر طرابلس بصناعة النحاس اليدوية التي تعود لمئات السنين',
];

const bigStats = [
  { value: '+٣٠٠٠', label: 'سنة من التاريخ' },
  { value: '+١٦٠', label: 'معلم تاريخي' },
  { value: '+٨٠', label: 'محل حلويات' },
  { value: '٥٠٠ألف', label: 'نسمة' },
];

const categoryColors: Record<string, string> = {
  'تاريخ': 'bg-blue-900/40 text-blue-300',
  'ثقافة': 'bg-violet-900/40 text-violet-300',
  'جغرافيا': 'bg-teal-900/40 text-teal-300',
  'تعليم': 'bg-emerald-900/40 text-emerald-300',
  'صناعة': 'bg-orange-900/40 text-orange-300',
  'معالم': 'bg-primary/15 text-primary',
  'ألقاب': 'bg-pink-900/40 text-pink-300',
};

export function Facts() {
  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-16 max-w-7xl mx-auto px-6 text-center">
        <motion.div {...fadeUp()}>
          <div className="text-primary text-sm font-medium tracking-widest mb-4">معلومات شيقة</div>
          <h1 className="text-5xl md:text-7xl font-bold mb-6" style={{ fontFamily: "'El Messiri', serif" }}>
            حقائق مميزة
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            اكتشف معلومات شيقة وفريدة عن طرابلس، المدينة التي لا تتوقف عن إبهارنا
          </p>
        </motion.div>
      </section>

      {/* Big Stats */}
      <section className="border-y border-border py-14">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {bigStats.map((s, i) => (
              <motion.div key={i} {...fadeUp(i * 0.08)} className="text-center">
                <div className="text-5xl md:text-6xl font-bold text-primary" style={{ fontFamily: "'El Messiri', serif" }}>{s.value}</div>
                <div className="text-sm text-muted-foreground mt-2">{s.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Facts Grid */}
      <section className="py-20 max-w-7xl mx-auto px-6">
        <motion.div {...fadeUp()} className="mb-12">
          <div className="text-primary text-sm font-medium tracking-widest mb-3">اكتشف</div>
          <h2 className="text-4xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>حقائق رائعة</h2>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {facts.map((fact, i) => {
            const Icon = fact.icon;
            return (
              <motion.div key={i} {...fadeUp(i * 0.06)}>
                <div className="bg-card border border-border rounded-2xl p-7 hover:border-primary/40 transition-all duration-300 group h-full">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                    <span className={`text-xs px-2.5 py-1 rounded-full mt-0.5 ${categoryColors[fact.category] || 'bg-secondary text-muted-foreground'}`}>
                      {fact.category}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors" style={{ fontFamily: "'El Messiri', serif" }}>
                    {fact.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{fact.description}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Records */}
      <section className="py-16 border-t border-border">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div {...fadeUp()} className="mb-12">
            <div className="text-primary text-sm font-medium tracking-widest mb-3">تميّز فريد</div>
            <h2 className="text-4xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>أرقام قياسية</h2>
          </motion.div>
          <div className="grid md:grid-cols-2 gap-5">
            {records.map((r, i) => (
              <motion.div key={i} {...fadeUp(i * 0.1)}>
                <div className="bg-card border border-border rounded-2xl p-7 hover:border-primary/40 transition-all duration-300 group">
                  <div className="flex items-start gap-4">
                    <span className="text-3xl font-bold text-primary/20 group-hover:text-primary/40 transition-colors shrink-0" style={{ fontFamily: "'El Messiri', serif" }}>
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <div>
                      <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors" style={{ fontFamily: "'El Messiri', serif" }}>
                        {r.title}
                      </h3>
                      <p className="text-muted-foreground text-sm leading-relaxed">{r.description}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Did you know */}
      <section className="py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div {...fadeUp()} className="mb-10">
            <div className="text-primary text-sm font-medium tracking-widest mb-3">مثير للاهتمام</div>
            <h2 className="text-4xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>هل تعلم؟</h2>
          </motion.div>
          <div className="space-y-3">
            {didYouKnow.map((fact, i) => (
              <motion.div key={i} {...fadeUp(i * 0.08)}>
                <div className="flex items-center gap-5 bg-card border border-border rounded-xl px-6 py-5 hover:border-primary/40 transition-all duration-300 group">
                  <span className="text-2xl font-bold text-primary/30 group-hover:text-primary transition-colors shrink-0 w-8" style={{ fontFamily: "'El Messiri', serif" }}>
                    {i + 1}
                  </span>
                  <p className="text-foreground leading-relaxed">{fact}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 px-6">
        <div className="max-w-4xl mx-auto">
          <motion.div {...fadeUp()} className="text-center bg-card border border-primary/20 rounded-3xl p-12 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/5" />
            <div className="relative">
              <h2 className="text-4xl font-bold mb-4" style={{ fontFamily: "'El Messiri', serif" }}>
                طرابلس... مدينة لا تنتهي عجائبها
              </h2>
              <p className="text-muted-foreground leading-relaxed max-w-2xl mx-auto">
                هذه مجرد لمحة بسيطة من حقائق طرابلس المميزة. كل زقاق وكل حجر يحمل قصة وسراً — ندعوك لزيارتها!
              </p>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
