import { ImageWithFallback } from './figma/ImageWithFallback';
import { Clock, Star, MapPin } from 'lucide-react';
import { motion } from 'motion/react';
import { useState } from 'react';

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 28 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] },
});

const places = [
  { name: 'قلعة طرابلس (قلعة سان جيل)', category: 'قلعة تاريخية', description: 'قلعة صليبية ضخمة تطل على المدينة، أعيد بناؤها في العصر المملوكي', hours: 'يومياً ٨:٠٠ ص - ٦:٠٠ م', recommended: true, type: 'تاريخي' },
  { name: 'الجامع المنصوري الكبير', category: 'معلم ديني', description: 'أكبر مساجد طرابلس، بُني في القرن الثالث عشر الميلادي بعمارة مملوكية فريدة', hours: 'أوقات الصلاة', recommended: true, type: 'ديني' },
  { name: 'سوق الذهب', category: 'سوق تقليدي', description: 'من أقدم أسواق الذهب في المنطقة، يضم محلات تقليدية لصياغة الذهب والفضة', hours: 'الاثنين - السبت ٩:٠٠ ص - ٧:٠٠ م', recommended: false, type: 'تسوق' },
  { name: 'سوق النحاسين', category: 'سوق حرفي', description: 'سوق تاريخي يبيع الأواني النحاسية المصنوعة يدوياً والحرف التقليدية', hours: 'الاثنين - السبت ٩:٠٠ ص - ٧:٠٠ م', recommended: true, type: 'تسوق' },
  { name: 'خان الخياطين', category: 'خان تاريخي', description: 'خان عثماني قديم تحول إلى سوق تقليدي للأقمشة والملابس', hours: 'يومياً ١٠:٠٠ ص - ٨:٠٠ م', recommended: false, type: 'تاريخي' },
  { name: 'الميناء القديم', category: 'ميناء', description: 'ميناء تاريخي يعود للعصر الفينيقي، يوفر إطلالة رائعة على البحر المتوسط', hours: 'على مدار اليوم', recommended: true, type: 'طبيعي' },
  { name: 'حمام العبد', category: 'حمام تقليدي', description: 'حمام عام تاريخي من العصر المملوكي، يعمل حتى اليوم كمتحف حي', hours: 'الأحد - الخميس ٩:٠٠ ص - ٥:٠٠ م', recommended: false, type: 'تاريخي' },
  { name: 'المدرسة القرطاوية', category: 'مدرسة تاريخية', description: 'مدرسة إسلامية من العصر المملوكي، تتميز بعمارتها الفريدة والزخارف الحجرية', hours: 'للزيارات الخارجية فقط', recommended: false, type: 'تاريخي' },
  { name: 'جزر النخيل', category: 'محمية طبيعية', description: 'محمية طبيعية على البحر، موطن للأرانب البرية والسلاحف البحرية', hours: 'رحلات بالقوارب من الميناء', recommended: true, type: 'طبيعي' },
];

const allTypes = ['الكل', 'تاريخي', 'ديني', 'تسوق', 'طبيعي'];

const typeStyles: Record<string, string> = {
  'تاريخي': 'bg-blue-900/40 text-blue-300 border-blue-700/40',
  'ديني': 'bg-primary/15 text-primary border-primary/30',
  'تسوق': 'bg-violet-900/40 text-violet-300 border-violet-700/40',
  'طبيعي': 'bg-emerald-900/40 text-emerald-300 border-emerald-700/40',
};

const tourSteps = [
  { step: '١', text: 'صباحاً: ابدأ بزيارة قلعة طرابلس والاستمتاع بالإطلالة البانورامية' },
  { step: '٢', text: 'قبل الظهر: تجول في سوق النحاسين والأسواق القديمة' },
  { step: '٣', text: 'الغداء: تذوق المأكولات التقليدية في أحد مطاعم السوق' },
  { step: '٤', text: 'بعد الظهر: زيارة الجامع المنصوري الكبير والمدارس التاريخية' },
  { step: '٥', text: 'المساء: استمتع بنزهة في الميناء القديم وتذوق الحلويات الشهيرة' },
];

export function Places() {
  const [activeType, setActiveType] = useState('الكل');

  const filtered = activeType === 'الكل' ? places : places.filter(p => p.type === activeType);

  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative h-[60vh] min-h-[440px] flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1651509245757-ce8f633950cc?w=1400&h=700&fit=crop&auto=format"
            alt="معالم طرابلس"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/55 to-transparent" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6 pb-14">
          <motion.div initial={{ opacity: 0, y: 32 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}>
            <div className="text-primary text-sm font-medium tracking-widest mb-4">السياحة</div>
            <h1 className="text-5xl md:text-7xl font-bold mb-4" style={{ fontFamily: "'El Messiri', serif" }}>
              الأماكن المميزة
            </h1>
            <p className="text-xl text-muted-foreground max-w-xl">
              اكتشف كنوز طرابلس السياحية التي لا تُنسى
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter tabs */}
      <section className="py-10 border-b border-border">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-2 flex-wrap">
            {allTypes.map(type => (
              <button
                key={type}
                onClick={() => setActiveType(type)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  activeType === type
                    ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25'
                    : 'border border-border text-muted-foreground hover:border-primary/40 hover:text-foreground'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Places Grid */}
      <section className="py-12 max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((place, i) => (
            <motion.div
              key={place.name}
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.06, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="bg-card border border-border rounded-2xl p-6 hover:border-primary/40 transition-all duration-300 group h-full flex flex-col">
                <div className="flex items-start justify-between mb-4 gap-2">
                  <div className="flex flex-wrap gap-2">
                    <span className={`text-xs px-2.5 py-1 rounded-full border ${typeStyles[place.type] || 'bg-secondary text-muted-foreground border-border'}`}>
                      {place.type}
                    </span>
                    <span className="text-xs px-2.5 py-1 rounded-full bg-secondary text-muted-foreground">
                      {place.category}
                    </span>
                  </div>
                  {place.recommended && (
                    <Star className="w-4 h-4 fill-primary text-primary shrink-0 mt-0.5" />
                  )}
                </div>

                <h3 className="text-lg font-bold mb-2 group-hover:text-primary transition-colors flex-1" style={{ fontFamily: "'El Messiri', serif" }}>
                  {place.name}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-4">{place.description}</p>

                <div className="flex items-center gap-2 text-xs text-muted-foreground mt-auto pt-4 border-t border-border">
                  <Clock className="w-3.5 h-3.5 text-primary" />
                  <span>{place.hours}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Suggested Tour */}
      <section className="py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div {...fadeUp()} className="relative rounded-3xl overflow-hidden border border-border bg-card">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent" />
            <div className="relative p-10 md:p-14">
              <div className="text-primary text-sm font-medium tracking-widest mb-4">مقترح سياحي</div>
              <div className="flex items-start gap-3 mb-8">
                <MapPin className="w-6 h-6 text-primary mt-1 shrink-0" />
                <h2 className="text-3xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>
                  جولة يوم كامل في طرابلس
                </h2>
              </div>
              <div className="space-y-4 max-w-2xl">
                {tourSteps.map((s, i) => (
                  <div key={i} className="flex items-start gap-4">
                    <div className="w-9 h-9 rounded-full bg-primary text-primary-foreground font-bold flex items-center justify-center shrink-0 text-sm">
                      {s.step}
                    </div>
                    <p className="text-foreground pt-1.5 leading-relaxed">{s.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Tips */}
      <section className="py-16 border-t border-border">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div {...fadeUp()} className="mb-10">
            <div className="text-primary text-sm font-medium tracking-widest mb-3">قبل زيارتك</div>
            <h2 className="text-3xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>نصائح للزوار</h2>
          </motion.div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { title: 'أفضل وقت للزيارة', text: 'الربيع والخريف (مارس-مايو، سبتمبر-نوفمبر)', icon: '🌤️' },
              { title: 'وسائل التنقل', text: 'المشي هو الأفضل لاستكشاف المدينة القديمة', icon: '🚶' },
              { title: 'لا تفوت', text: 'تجربة الحلويات الطرابلسية الأصيلة قبل مغادرتك', icon: '🍯' },
            ].map((tip, i) => (
              <motion.div key={i} {...fadeUp(i * 0.1)}>
                <div className="bg-card border border-border rounded-2xl p-6 text-center hover:border-primary/40 transition-all duration-300">
                  <div className="text-4xl mb-4">{tip.icon}</div>
                  <h3 className="font-bold text-lg mb-2" style={{ fontFamily: "'El Messiri', serif" }}>{tip.title}</h3>
                  <p className="text-muted-foreground text-sm">{tip.text}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
