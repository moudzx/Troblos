import { ImageWithFallback } from './figma/ImageWithFallback';
import { motion } from 'motion/react';

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 28 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] },
});

const timeline = [
  { period: 'العصر الفينيقي', year: '١٤٠٠ ق.م', description: 'تأسست طرابلس كمركز تجاري فينيقي مهم على ساحل البحر المتوسط' },
  { period: 'العصر الروماني', year: '٦٤ ق.م', description: 'أصبحت طرابلس جزءاً من الإمبراطورية الرومانية وازدهرت كمركز للتجارة والثقافة' },
  { period: 'العصر الإسلامي', year: '٦٣٨ م', description: 'الفتح الإسلامي لطرابلس، بداية حقبة جديدة من الازدهار الحضاري' },
  { period: 'العصر المملوكي', year: '١٢٨٩ م', description: 'العصر الذهبي لطرابلس — بناء القلاع والمساجد والأسواق التاريخية' },
  { period: 'العصر العثماني', year: '١٥١٦ م', description: 'أربعة قرون من الحكم العثماني مع تطور معماري وثقافي مميز' },
  { period: 'لبنان الحديث', year: '١٩٤٣ م', description: 'استقلال لبنان وطرابلس عاصمة الشمال اللبناني' },
];

const monuments = [
  { name: 'قلعة طرابلس', period: 'العصر الصليبي - المملوكي', description: 'قلعة ضخمة بناها الصليبيون وأعاد المماليك بناءها، تطل على المدينة من أعلى تلة' },
  { name: 'الجامع المنصوري الكبير', period: 'العصر المملوكي', description: 'أكبر وأقدم جامع في طرابلس، يعود تاريخه للقرن الثالث عشر' },
  { name: 'خان الخياطين', period: 'العصر العثماني', description: 'خان تجاري تاريخي يضم محلات تقليدية للملابس والأقمشة' },
  { name: 'برج الساعة', period: 'العصر العثماني', description: 'معلم تاريخي يقع في ساحة التل وسط المدينة القديمة' },
];

const legacy = [
  'أكبر تجمع للعمارة المملوكية في لبنان',
  'المدينة القديمة مرشحة لقائمة التراث العالمي',
  'محافظة على طابعها التاريخي الأصيل',
];

export function History() {
  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative h-[70vh] min-h-[500px] flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1572252009286-268acec5ca0a?w=1400&h=800&fit=crop&auto=format"
            alt="تاريخ طرابلس"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/55 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-background/70 to-transparent" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6 pb-16">
          <motion.div initial={{ opacity: 0, y: 32 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}>
            <div className="text-primary text-sm font-medium tracking-widest mb-4">عبر الزمن</div>
            <h1 className="text-5xl md:text-7xl font-bold mb-4" style={{ fontFamily: "'El Messiri', serif" }}>
              تاريخ طرابلس
            </h1>
            <p className="text-xl text-muted-foreground max-w-xl">
              حضارة عمرها آلاف السنين — كل حجر يحكي قصة
            </p>
          </motion.div>
        </div>
      </section>

      {/* Intro card */}
      <section className="py-16 max-w-7xl mx-auto px-6">
        <motion.div {...fadeUp()} className="relative rounded-2xl overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-l from-primary/8 to-card" />
          <div className="relative border border-border rounded-2xl p-8 md:p-12">
            <div className="text-primary text-sm font-medium tracking-widest mb-4">مدينة عبر العصور</div>
            <p className="text-lg text-muted-foreground leading-relaxed max-w-4xl">
              طرابلس هي واحدة من أقدم المدن المأهولة في العالم، يعود تاريخها إلى العصر الفينيقي قبل
              أكثر من 3000 عام. عبر القرون، حكمت المدينة حضارات عديدة منها الفينيقيون، الرومان، البيزنطيون،
              العرب، الصليبيون، المماليك، والعثمانيون — كل حضارة تركت بصمتها الفريدة في معالم المدينة وثقافتها.
            </p>
          </div>
        </motion.div>
      </section>

      {/* Timeline */}
      <section className="py-8 pb-20 max-w-7xl mx-auto px-6">
        <motion.div {...fadeUp()} className="mb-12">
          <div className="text-primary text-sm font-medium tracking-widest mb-3">الحقب التاريخية</div>
          <h2 className="text-4xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>رحلة عبر الزمن</h2>
        </motion.div>

        <div className="relative">
          {/* Vertical line */}
          <div className="absolute right-6 md:right-1/2 top-0 bottom-0 w-px bg-border" />

          <div className="space-y-8">
            {timeline.map((era, i) => (
              <motion.div
                key={i}
                {...fadeUp(i * 0.1)}
                className={`relative flex gap-8 ${i % 2 === 0 ? 'md:flex-row-reverse' : ''}`}
              >
                {/* Dot */}
                <div className="absolute right-4 md:right-1/2 md:-translate-x-1/2 w-4 h-4 rounded-full bg-primary border-4 border-background top-6 z-10 translate-x-1/2" style={{ right: i % 2 === 0 ? undefined : undefined }} />

                {/* Content */}
                <div className={`w-full md:w-[calc(50%-2rem)] mr-12 md:mr-0 ${i % 2 === 0 ? 'md:ml-12' : 'md:mr-12'}`}>
                  <div className="bg-card border border-border rounded-2xl p-6 hover:border-primary/40 transition-all duration-300 group">
                    <div className="flex items-start justify-between mb-3 gap-3">
                      <h3 className="text-xl font-bold group-hover:text-primary transition-colors" style={{ fontFamily: "'El Messiri', serif" }}>
                        {era.period}
                      </h3>
                      <span className="text-xs px-3 py-1 rounded-full bg-primary/15 text-primary border border-primary/30 shrink-0">
                        {era.year}
                      </span>
                    </div>
                    <p className="text-muted-foreground text-sm leading-relaxed">{era.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Monuments */}
      <section className="py-16 border-t border-border">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div {...fadeUp()} className="mb-12">
            <div className="text-primary text-sm font-medium tracking-widest mb-3">إرث معماري</div>
            <h2 className="text-4xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>المعالم التاريخية</h2>
          </motion.div>
          <div className="grid md:grid-cols-2 gap-5">
            {monuments.map((m, i) => (
              <motion.div key={i} {...fadeUp(i * 0.1)}>
                <div className="bg-card border border-border rounded-2xl p-7 hover:border-primary/40 transition-all duration-300 group h-full">
                  <span className="text-xs px-2.5 py-1 rounded-full border border-primary/30 text-primary mb-4 inline-block">
                    {m.period}
                  </span>
                  <h3 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors" style={{ fontFamily: "'El Messiri', serif" }}>
                    {m.name}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{m.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Legacy Split */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div {...fadeUp()} className="grid md:grid-cols-2 gap-8 items-center rounded-3xl overflow-hidden border border-border">
            <div className="aspect-video md:aspect-auto md:h-full min-h-[300px] overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1512970648279-ff3398568f77?w=800&h=600&fit=crop&auto=format"
                alt="العمارة التاريخية"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-l from-transparent to-background/20" />
            </div>
            <div className="p-10 md:p-12 bg-card">
              <div className="text-primary text-sm font-medium tracking-widest mb-4">الأهمية التاريخية</div>
              <h2 className="text-3xl font-bold mb-5" style={{ fontFamily: "'El Messiri', serif" }}>
                إرث حضاري خالد
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-8">
                تعتبر طرابلس من أغنى المدن اللبنانية بالمعالم التاريخية، حيث تحتوي على أكثر من 160 معلماً
                تاريخياً مصنفاً، من بينها مساجد، كنائس، مدارس، خانات، وحمامات تعود للعصور المملوكية والعثمانية.
              </p>
              <ul className="space-y-3">
                {legacy.map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm">
                    <span className="w-5 h-5 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center shrink-0">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                    </span>
                    <span className="text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
