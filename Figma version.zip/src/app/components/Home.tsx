import { ImageWithFallback } from './figma/ImageWithFallback';
import { Link } from 'react-router';
import { Utensils, Clock, Image as ImageIcon, MapPin, Lightbulb, Calendar, ArrowLeft } from 'lucide-react';
import { motion } from 'motion/react';

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 32 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] },
});

const features = [
  {
    icon: Utensils,
    title: 'الطعام التقليدي',
    description: 'اكتشف أشهى المأكولات اللبنانية الأصيلة',
    link: '/food',
    gold: true,
  },
  {
    icon: Clock,
    title: 'التاريخ العريق',
    description: 'رحلة عبر قرون من الحضارة والثقافة',
    link: '/history',
    gold: false,
  },
  {
    icon: ImageIcon,
    title: 'معرض الصور',
    description: 'شاهد جمال طرابلس في صور رائعة',
    link: '/gallery',
    gold: true,
  },
  {
    icon: MapPin,
    title: 'الأماكن المميزة',
    description: 'تعرف على أجمل المعالم السياحية',
    link: '/places',
    gold: false,
  },
  {
    icon: Lightbulb,
    title: 'حقائق فريدة',
    description: 'معلومات شيقة عن المدينة',
    link: '/facts',
    gold: true,
  },
  {
    icon: Calendar,
    title: 'احجز زيارتك',
    description: 'خطط لزيارتك القادمة إلى طرابلس',
    link: '/booking',
    gold: false,
  },
];

const stats = [
  { value: '+٣٠٠٠', label: 'سنة من التاريخ' },
  { value: '+١٦٠', label: 'معلم تاريخي' },
  { value: '٥٠٠,٠٠٠', label: 'نسمة' },
  { value: '+٨٠', label: 'محل حلويات' },
];

export function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-background">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1707154823171-ac8528f65b6b?w=1600&h=900&fit=crop&auto=format"
            alt="طرابلس - عروس الشمال"
            className="w-full h-full object-cover opacity-30"
          />
          {/* Color grade overlays */}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/20" />
          <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-transparent to-background/40" />
        </div>

        {/* Decorative gold orb */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-[#c9a84c]/6 blur-[120px] pointer-events-none" />

        <div className="relative z-10 text-center max-w-4xl mx-auto px-6 pt-28">
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="inline-flex items-center gap-2 border border-primary/30 rounded-full px-4 py-1.5 text-xs text-primary mb-8 backdrop-blur-sm bg-primary/5">
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              لبنان — الشمال
            </div>

            <h1 className="text-6xl md:text-8xl font-bold leading-tight mb-6" style={{ fontFamily: "'El Messiri', serif" }}>
              <span className="block text-foreground">مرحباً بكم في</span>
              <span className="block bg-gradient-to-l from-[#c9a84c] via-[#e6c96a] to-[#b8943c] bg-clip-text text-transparent">
                طرابلس
              </span>
            </h1>

            <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed mb-12">
              عروس الشمال اللبناني — مدينة تحمل في طياتها ثلاثة آلاف عام من التاريخ، الثقافة، والجمال الساحر
            </p>

            <div className="flex gap-4 justify-center flex-wrap">
              <Link to="/gallery">
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.97 }}
                  className="px-8 py-3.5 bg-primary text-primary-foreground font-semibold rounded-full hover:opacity-90 transition-all shadow-lg shadow-primary/25"
                >
                  استكشف المعرض
                </motion.button>
              </Link>
              <Link to="/booking">
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.97 }}
                  className="px-8 py-3.5 border border-foreground/20 text-foreground rounded-full hover:border-primary/60 hover:text-primary transition-all backdrop-blur-sm"
                >
                  احجز زيارتك
                </motion.button>
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
            className="w-6 h-9 border-2 border-foreground/20 rounded-full flex items-start justify-center p-1"
          >
            <div className="w-1 h-2 bg-primary rounded-full" />
          </motion.div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-24 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div {...fadeUp(0)}>
            <div className="text-primary text-sm font-medium tracking-widest uppercase mb-4">عن المدينة</div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight" style={{ fontFamily: "'El Messiri', serif" }}>
              طرابلس<br />
              <span className="text-primary">جوهرة لبنان</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed text-lg mb-8">
              طرابلس هي ثاني أكبر مدينة في لبنان وعاصمة الشمال، تتميز بتاريخها العريق الممتد لآلاف السنين
              وتراثها الثقافي الغني. تشتهر المدينة بأسواقها التقليدية، معالمها التاريخية، وحلوياتها الشهيرة
              التي تجذب الزوار من جميع أنحاء العالم.
            </p>
            <Link to="/history" className="inline-flex items-center gap-2 text-primary font-medium hover:gap-3 transition-all">
              <ArrowLeft className="w-4 h-4" />
              اكتشف التاريخ
            </Link>
          </motion.div>

          <motion.div {...fadeUp(0.15)} className="relative">
            <div className="aspect-[4/3] rounded-2xl overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1512970648279-ff3398568f77?w=800&h=600&fit=crop&auto=format"
                alt="العمارة التاريخية في طرابلس"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent" />
            </div>
            {/* Gold accent card */}
            <div className="absolute -bottom-6 -right-6 bg-card border border-border rounded-2xl p-5 shadow-2xl">
              <div className="text-3xl font-bold text-primary" style={{ fontFamily: "'El Messiri', serif" }}>+٣٠٠٠</div>
              <div className="text-xs text-muted-foreground mt-1">سنة من التاريخ</div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="py-16 border-y border-border">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <motion.div key={i} {...fadeUp(i * 0.08)} className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-primary mb-2" style={{ fontFamily: "'El Messiri', serif" }}>
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 max-w-7xl mx-auto px-6">
        <motion.div {...fadeUp()} className="text-center mb-16">
          <div className="text-primary text-sm font-medium tracking-widest uppercase mb-4">استكشف</div>
          <h2 className="text-4xl md:text-5xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>
            اكتشف طرابلس
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div key={index} {...fadeUp(index * 0.07)}>
                <Link to={feature.link} className="block group">
                  <div className="relative bg-card border border-border rounded-2xl p-7 hover:border-primary/50 transition-all duration-400 overflow-hidden">
                    {/* Glow on hover */}
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/0 via-primary/0 to-primary/0 group-hover:from-primary/5 group-hover:to-primary/8 transition-all duration-500 rounded-2xl" />

                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-5 ${
                      feature.gold
                        ? 'bg-primary/15 text-primary'
                        : 'bg-secondary text-muted-foreground group-hover:bg-primary/15 group-hover:text-primary'
                    } transition-all duration-300`}>
                      <Icon className="w-6 h-6" />
                    </div>

                    <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors" style={{ fontFamily: "'El Messiri', serif" }}>
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {feature.description}
                    </p>

                    <div className="mt-6 flex items-center gap-1.5 text-xs text-primary opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0 duration-300">
                      <ArrowLeft className="w-3.5 h-3.5" />
                      اكتشف المزيد
                    </div>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-8 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            {...fadeUp()}
            className="relative rounded-3xl overflow-hidden"
          >
            <div className="absolute inset-0">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1651509245757-ce8f633950cc?w=1400&h=500&fit=crop&auto=format"
                alt="طرابلس"
                className="w-full h-full object-cover opacity-25"
              />
              <div className="absolute inset-0 bg-gradient-to-l from-primary/20 to-[hsl(222_47%_8%)]" />
            </div>
            <div className="relative z-10 py-16 px-12 text-center">
              <h2 className="text-4xl md:text-5xl font-bold mb-4" style={{ fontFamily: "'El Messiri', serif" }}>
                جاهز لزيارة طرابلس؟
              </h2>
              <p className="text-muted-foreground text-lg mb-8 max-w-xl mx-auto">
                احجز رحلتك الآن واستمتع بتجربة لا تُنسى في عروس الشمال
              </p>
              <Link to="/booking">
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.97 }}
                  className="px-10 py-4 bg-primary text-primary-foreground font-bold rounded-full text-lg hover:opacity-90 transition-all shadow-xl shadow-primary/30"
                >
                  احجز الآن
                </motion.button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
