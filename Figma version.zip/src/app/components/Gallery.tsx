import { useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { X, ChevronLeft, ChevronRight, ZoomIn } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import hammam from '../../imports/hammam.jpg';
import img0 from '../../imports/img0.jpg';
import img1 from '../../imports/img1.jpg';
import img2 from '../../imports/img2.jpg';
import img3 from '../../imports/img3.jpg';
import img5 from '../../imports/img5.jpg';
import img6 from '../../imports/img6.jpg';
import img7 from '../../imports/img7.jpg';
import img8 from '../../imports/img8.jpg';
import img9 from '../../imports/img9.jpg';

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] },
});

const images = [
  { src: hammam, title: 'الحمام التقليدي', description: 'من معالم العمارة التقليدية في طرابلس' },
  { src: img0, title: 'مشهد من المدينة', description: 'جمال العمارة والطبيعة' },
  { src: img1, title: 'المعالم التاريخية', description: 'شاهد على حضارة عريقة' },
  { src: img2, title: 'الأزقة القديمة', description: 'سحر المدينة القديمة' },
  { src: img3, title: 'التراث المعماري', description: 'فن العمارة الإسلامية' },
  { src: img5, title: 'مناظر طرابلس', description: 'جمال المدينة الساحلية' },
  { src: img6, title: 'الأسواق التقليدية', description: 'قلب المدينة النابض' },
  { src: img7, title: 'المباني التاريخية', description: 'روائع معمارية خالدة' },
  { src: img8, title: 'حياة المدينة', description: 'نبض الحياة اليومية' },
  { src: img9, title: 'تفاصيل معمارية', description: 'جمال في التفاصيل' },
];

export function Gallery() {
  const [selected, setSelected] = useState<number | null>(null);

  const prev = () => selected !== null && setSelected((selected - 1 + images.length) % images.length);
  const next = () => selected !== null && setSelected((selected + 1) % images.length);

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowLeft') next();
    if (e.key === 'ArrowRight') prev();
    if (e.key === 'Escape') setSelected(null);
  };

  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-16 max-w-7xl mx-auto px-6">
        <motion.div {...fadeUp()} className="text-center">
          <div className="text-primary text-sm font-medium tracking-widest mb-4">لقطات من القلب</div>
          <h1 className="text-5xl md:text-7xl font-bold mb-6" style={{ fontFamily: "'El Messiri', serif" }}>
            معرض الصور
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            استكشف جمال طرابلس من خلال عدسة تلتقط روح المدينة وعمقها التاريخي
          </p>
        </motion.div>
      </section>

      {/* Masonry-style Grid */}
      <section className="max-w-7xl mx-auto px-6 pb-24">
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4">
          {images.map((img, i) => (
            <motion.div
              key={i}
              {...fadeUp(i * 0.06)}
              className="break-inside-avoid group relative rounded-2xl overflow-hidden cursor-pointer"
              onClick={() => setSelected(i)}
              whileHover={{ scale: 1.01 }}
              transition={{ duration: 0.25 }}
            >
              <ImageWithFallback
                src={img.src}
                alt={img.title}
                className={`w-full object-cover transition-transform duration-500 group-hover:scale-105 ${
                  i % 3 === 0 ? 'aspect-[3/4]' : i % 3 === 1 ? 'aspect-[4/3]' : 'aspect-square'
                }`}
              />
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-400" />

              {/* Content */}
              <div className="absolute bottom-0 inset-x-0 p-5 translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-400">
                <h3 className="text-lg font-bold text-foreground mb-0.5" style={{ fontFamily: "'El Messiri', serif" }}>
                  {img.title}
                </h3>
                <p className="text-xs text-muted-foreground">{img.description}</p>
              </div>

              {/* Zoom icon */}
              <div className="absolute top-3 left-3 w-9 h-9 rounded-full bg-background/60 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 scale-75 group-hover:scale-100">
                <ZoomIn className="w-4 h-4 text-primary" />
              </div>

              {/* Number badge */}
              <div className="absolute top-3 right-3 w-7 h-7 rounded-full bg-primary/80 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
                <span className="text-xs font-bold text-primary-foreground">{i + 1}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {selected !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center"
            onClick={() => setSelected(null)}
            onKeyDown={handleKey}
            tabIndex={0}
          >
            {/* Close */}
            <button
              className="absolute top-5 right-5 w-10 h-10 rounded-full bg-foreground/10 hover:bg-foreground/20 flex items-center justify-center text-foreground transition-colors z-10"
              onClick={() => setSelected(null)}
            >
              <X className="w-5 h-5" />
            </button>

            {/* Counter */}
            <div className="absolute top-5 left-5 text-sm text-muted-foreground">
              {selected + 1} / {images.length}
            </div>

            {/* Prev */}
            <button
              className="absolute right-5 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-foreground/10 hover:bg-primary/20 flex items-center justify-center text-foreground hover:text-primary transition-all z-10"
              onClick={(e) => { e.stopPropagation(); prev(); }}
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Next */}
            <button
              className="absolute left-5 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-foreground/10 hover:bg-primary/20 flex items-center justify-center text-foreground hover:text-primary transition-all z-10"
              onClick={(e) => { e.stopPropagation(); next(); }}
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* Image */}
            <motion.div
              key={selected}
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.3 }}
              className="max-w-5xl max-h-[85vh] mx-14 rounded-xl overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <ImageWithFallback
                src={images[selected].src}
                alt={images[selected].title}
                className="max-w-full max-h-[75vh] object-contain mx-auto block"
              />
              <div className="bg-card/80 backdrop-blur-sm p-5 text-center" dir="rtl">
                <h3 className="text-xl font-bold mb-1" style={{ fontFamily: "'El Messiri', serif" }}>
                  {images[selected].title}
                </h3>
                <p className="text-sm text-muted-foreground">{images[selected].description}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
