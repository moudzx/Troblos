import { ImageWithFallback } from './figma/ImageWithFallback';
import { motion } from 'motion/react';

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 28 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] },
});

const dishes = [
  { name: 'الكبة الطرابلسية', description: 'من أشهر الأطباق اللبنانية، تتكون من البرغل واللحم المفروم بتوابل خاصة', category: 'طبق رئيسي', specialty: true },
  { name: 'الحلويات الطرابلسية', description: 'تشتهر طرابلس بحلوياتها المميزة مثل الحلاوة، البقلاوة، والكنافة بأنواعها', category: 'حلويات', specialty: true },
  { name: 'المجدرة', description: 'طبق تقليدي من العدس والأرز والبصل المقلي', category: 'طبق رئيسي', specialty: false },
  { name: 'السمك المشوي', description: 'سمك طازج من البحر المتوسط مع الطحينة والليمون', category: 'مأكولات بحرية', specialty: false },
  { name: 'المعمول', description: 'كعك محشو بالتمر أو الجوز، من أشهر حلويات الأعياد', category: 'حلويات', specialty: false },
  { name: 'المناقيش', description: 'خبز مخبوز مع الزعتر أو الجبنة، إفطار تقليدي', category: 'مخبوزات', specialty: false },
];

const souks = [
  { name: 'سوق الحلويات', description: 'أقدم سوق للحلويات في طرابلس، يضم أشهر محلات البقلاوة والكنافة', number: '٠١' },
  { name: 'سوق النحاسين', description: 'سوق تقليدي يبيع الأواني النحاسية والمطبخية التقليدية', number: '٠٢' },
  { name: 'سوق العطارين', description: 'يشتهر بالتوابل والأعشاب والمكسرات اللبنانية', number: '٠٣' },
];

const categoryColors: Record<string, string> = {
  'طبق رئيسي': 'bg-blue-900/40 text-blue-300 border-blue-700/40',
  'حلويات': 'bg-primary/15 text-primary border-primary/30',
  'مأكولات بحرية': 'bg-teal-900/40 text-teal-300 border-teal-700/40',
  'مخبوزات': 'bg-amber-900/30 text-amber-300 border-amber-700/30',
};

export function Food() {
  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative h-[70vh] min-h-[500px] flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1661083098412-054431ab7112?w=1400&h=800&fit=crop&auto=format"
            alt="المطبخ الطرابلسي"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-background/70 to-transparent" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6 pb-16">
          <motion.div
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="text-primary text-sm font-medium tracking-widest mb-4">المطبخ الأصيل</div>
            <h1 className="text-5xl md:text-7xl font-bold mb-4" style={{ fontFamily: "'El Messiri', serif" }}>
              المطبخ الطرابلسي
            </h1>
            <p className="text-xl text-muted-foreground max-w-xl">
              رحلة في عالم النكهات الأصيلة — حيث كل طبق يحكي قصة
            </p>
          </motion.div>
        </div>
      </section>

      {/* Intro */}
      <section className="py-20 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div {...fadeUp(0)}>
            <div className="text-primary text-sm font-medium tracking-widest mb-4">تراث طعام عريق</div>
            <h2 className="text-4xl font-bold mb-6" style={{ fontFamily: "'El Messiri', serif" }}>
              نكهات لا تُنسى
            </h2>
            <p className="text-muted-foreground leading-relaxed text-lg">
              يعتبر المطبخ الطرابلسي من أغنى المطابخ اللبنانية، حيث يجمع بين الأصالة والتنوع. تشتهر طرابلس
              بحلوياتها الفريدة التي تُصنع بأيدي حرفيين ماهرين ورثوا هذه المهنة عن أجدادهم. كما تتميز المدينة
              بأطباقها التقليدية التي تعكس تاريخاً طويلاً من التبادل الثقافي والحضاري.
            </p>
          </motion.div>
          <motion.div {...fadeUp(0.15)} className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden max-w-sm mx-auto lg:mx-0">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1761828122856-8703baac8e86?w=600&h=600&fit=crop&auto=format"
                alt="حلويات طرابلس"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/40 to-transparent" />
            </div>
            <div className="absolute -bottom-4 -left-4 bg-card border border-border rounded-2xl p-4 shadow-2xl">
              <div className="text-2xl font-bold text-primary" style={{ fontFamily: "'El Messiri', serif" }}>+٨٠</div>
              <div className="text-xs text-muted-foreground">محل حلويات تقليدي</div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Dishes */}
      <section className="py-16 border-t border-border">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div {...fadeUp()} className="mb-12">
            <div className="text-primary text-sm font-medium tracking-widest mb-3">قائمة الأطباق</div>
            <h2 className="text-4xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>أشهر الأطباق</h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {dishes.map((dish, i) => (
              <motion.div key={i} {...fadeUp(i * 0.07)}>
                <div className="bg-card border border-border rounded-2xl p-6 hover:border-primary/40 transition-all duration-300 group h-full">
                  <div className="flex items-start justify-between mb-3">
                    <span className={`text-xs px-2.5 py-1 rounded-full border ${categoryColors[dish.category] || 'bg-secondary text-muted-foreground border-border'}`}>
                      {dish.category}
                    </span>
                    {dish.specialty && (
                      <span className="text-xs px-2.5 py-1 rounded-full bg-primary/15 text-primary border border-primary/30">
                        مميز ★
                      </span>
                    )}
                  </div>
                  <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors" style={{ fontFamily: "'El Messiri', serif" }}>
                    {dish.name}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{dish.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Sweets Highlight */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            {...fadeUp()}
            className="relative rounded-3xl overflow-hidden"
          >
            <div className="absolute inset-0">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1579888944880-d98341245702?w=1400&h=600&fit=crop&auto=format"
                alt="حلويات"
                className="w-full h-full object-cover opacity-20"
              />
              <div className="absolute inset-0 bg-gradient-to-l from-primary/10 to-background/95" />
            </div>
            <div className="relative z-10 p-10 md:p-16">
              <div className="grid md:grid-cols-2 gap-12 items-center">
                <div>
                  <div className="text-primary text-sm font-medium tracking-widest mb-4">حلويات لا مثيل لها</div>
                  <h2 className="text-4xl font-bold mb-5" style={{ fontFamily: "'El Messiri', serif" }}>
                    حلويات طرابلس الشهيرة
                  </h2>
                  <p className="text-muted-foreground leading-relaxed mb-6">
                    تعتبر طرابلس عاصمة الحلويات في لبنان والعالم العربي. تشتهر المدينة بالبقلاوة، الكنافة،
                    المعمول، والحلاوة الطحينية. يعود تاريخ صناعة الحلويات في طرابلس لمئات السنين.
                  </p>
                  <div className="bg-primary/10 border border-primary/20 rounded-xl p-4">
                    <p className="text-sm text-foreground">
                      <span className="text-primary font-semibold">هل تعلم؟</span> يوجد في طرابلس أكثر من 80 محل حلويات تقليدي، بعضها يعود تاريخه لأكثر من 150 عاماً!
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {['البقلاوة', 'الكنافة', 'المعمول', 'الحلاوة'].map((sweet, i) => (
                    <div key={i} className="bg-card/80 backdrop-blur-sm border border-border rounded-xl p-5 text-center">
                      <div className="text-3xl mb-2">{['🍯', '🧁', '🍪', '🫘'][i]}</div>
                      <div className="font-semibold text-sm">{sweet}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Souks */}
      <section className="py-16 border-t border-border">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div {...fadeUp()} className="mb-12">
            <div className="text-primary text-sm font-medium tracking-widest mb-3">أسواق الطعام</div>
            <h2 className="text-4xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>الأسواق التقليدية</h2>
          </motion.div>
          <div className="grid md:grid-cols-3 gap-6">
            {souks.map((souk, i) => (
              <motion.div key={i} {...fadeUp(i * 0.1)}>
                <div className="border border-border rounded-2xl p-7 hover:border-primary/40 transition-all duration-300 group">
                  <div className="text-5xl font-bold text-primary/20 mb-4 group-hover:text-primary/40 transition-colors" style={{ fontFamily: "'El Messiri', serif" }}>
                    {souk.number}
                  </div>
                  <h3 className="text-xl font-bold mb-3" style={{ fontFamily: "'El Messiri', serif" }}>{souk.name}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{souk.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
