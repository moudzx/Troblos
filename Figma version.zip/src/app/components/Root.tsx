import { Outlet, Link, useLocation } from 'react-router';
import { useAuth } from '../context/AuthContext';
import {
  MapPin, Utensils, Clock, Image as ImageIcon,
  Lightbulb, Calendar, LogOut, LogIn, Menu, X
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

const navItems = [
  { path: '/', label: 'الرئيسية', icon: MapPin },
  { path: '/food', label: 'الطعام', icon: Utensils },
  { path: '/history', label: 'التاريخ', icon: Clock },
  { path: '/gallery', label: 'المعرض', icon: ImageIcon },
  { path: '/places', label: 'الأماكن', icon: MapPin },
  { path: '/facts', label: 'حقائق مميزة', icon: Lightbulb },
  { path: '/booking', label: 'احجز زيارتك', icon: Calendar },
];

export function Root() {
  const location = useLocation();
  const { user, login, register, logout, isAuthenticated } = useAuth();
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [registerName, setRegisterName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    await login(loginEmail, loginPassword);
    setAuthDialogOpen(false);
    setLoginEmail(''); setLoginPassword('');
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    await register(registerName, registerEmail, registerPassword);
    setAuthDialogOpen(false);
    setRegisterName(''); setRegisterEmail(''); setRegisterPassword('');
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-[hsl(222_47%_5%/0.92)] backdrop-blur-xl border-b border-border shadow-2xl shadow-black/40'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between gap-8">
            {/* Auth button */}
            <div className="flex items-center gap-3">
              {isAuthenticated ? (
                <button
                  onClick={logout}
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="hidden sm:inline">{user?.name}</span>
                </button>
              ) : (
                <button
                  onClick={() => setAuthDialogOpen(true)}
                  className="flex items-center gap-2 text-sm px-4 py-2 border border-primary/40 text-primary rounded-full hover:bg-primary hover:text-primary-foreground transition-all duration-300"
                >
                  <LogIn className="w-4 h-4" />
                  <span>دخول</span>
                </button>
              )}

              {/* Mobile menu toggle */}
              <button
                className="lg:hidden text-foreground p-1"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>

            {/* Logo */}
            <Link to="/" className="text-center shrink-0">
              <div className="text-3xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>
                <span className="bg-gradient-to-l from-[#c9a84c] via-[#e6c96a] to-[#c9a84c] bg-clip-text text-transparent">
                  طرابلس
                </span>
              </div>
              <div className="text-xs text-muted-foreground tracking-widest mt-0.5">عروس الشمال اللبناني</div>
            </Link>

            {/* Desktop nav */}
            <nav className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => {
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`relative px-4 py-2 text-sm font-medium rounded-full transition-all duration-300 ${
                      isActive
                        ? 'text-primary-foreground'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    {isActive && (
                      <motion.span
                        layoutId="nav-pill"
                        className="absolute inset-0 bg-primary rounded-full"
                        transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                      />
                    )}
                    <span className="relative z-10">{item.label}</span>
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Mobile Nav Drawer */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.nav
              initial={{ opacity: 0, y: -12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.22 }}
              className="lg:hidden border-t border-border bg-[hsl(222_47%_5%/0.97)] backdrop-blur-xl px-6 py-4"
            >
              <div className="flex flex-col gap-1">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.path;
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                        isActive
                          ? 'bg-primary text-primary-foreground'
                          : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      {item.label}
                    </Link>
                  );
                })}
              </div>
            </motion.nav>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content */}
      <main>
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-24">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="flex flex-col items-center gap-4 text-center">
            <div className="text-4xl font-bold bg-gradient-to-l from-[#c9a84c] via-[#e6c96a] to-[#c9a84c] bg-clip-text text-transparent" style={{ fontFamily: "'El Messiri', serif" }}>
              طرابلس
            </div>
            <p className="text-muted-foreground text-sm max-w-md">
              مدينة التاريخ والثقافة والحضارة — عروس الشمال اللبناني
            </p>
            <div className="h-px w-24 bg-gradient-to-l from-transparent via-primary to-transparent" />
            <p className="text-xs text-muted-foreground/50">© 2024 طرابلس السياحية</p>
          </div>
        </div>
      </footer>

      {/* Auth Dialog */}
      <Dialog open={authDialogOpen} onOpenChange={setAuthDialogOpen}>
        <DialogContent className="sm:max-w-md bg-card border-border" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl" style={{ fontFamily: "'El Messiri', serif" }}>
              مرحباً بك
            </DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-secondary">
              <TabsTrigger value="login" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">تسجيل الدخول</TabsTrigger>
              <TabsTrigger value="register" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">إنشاء حساب</TabsTrigger>
            </TabsList>
            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-4 pt-2">
                <div className="space-y-2">
                  <Label htmlFor="login-email" className="text-foreground">البريد الإلكتروني</Label>
                  <Input id="login-email" type="email" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} required className="bg-secondary border-border text-foreground" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password" className="text-foreground">كلمة المرور</Label>
                  <Input id="login-password" type="password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} required className="bg-secondary border-border text-foreground" />
                </div>
                <button type="submit" className="w-full py-2.5 bg-primary text-primary-foreground font-semibold rounded-lg hover:opacity-90 transition-opacity">
                  تسجيل الدخول
                </button>
              </form>
            </TabsContent>
            <TabsContent value="register">
              <form onSubmit={handleRegister} className="space-y-4 pt-2">
                <div className="space-y-2">
                  <Label htmlFor="register-name" className="text-foreground">الاسم الكامل</Label>
                  <Input id="register-name" type="text" value={registerName} onChange={(e) => setRegisterName(e.target.value)} required className="bg-secondary border-border text-foreground" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-email" className="text-foreground">البريد الإلكتروني</Label>
                  <Input id="register-email" type="email" value={registerEmail} onChange={(e) => setRegisterEmail(e.target.value)} required className="bg-secondary border-border text-foreground" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-password" className="text-foreground">كلمة المرور</Label>
                  <Input id="register-password" type="password" value={registerPassword} onChange={(e) => setRegisterPassword(e.target.value)} required className="bg-secondary border-border text-foreground" />
                </div>
                <button type="submit" className="w-full py-2.5 bg-primary text-primary-foreground font-semibold rounded-lg hover:opacity-90 transition-opacity">
                  إنشاء حساب
                </button>
              </form>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}
