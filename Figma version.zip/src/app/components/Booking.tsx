import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Calendar as CalendarIcon, MapPin, Users, Clock, CheckCircle2, AlertCircle, ArrowLeft } from 'lucide-react';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import { motion } from 'motion/react';
import { Link } from 'react-router';

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 28 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] },
});

const tourPackages = [
  {
    title: 'جولة المدينة القديمة',
    duration: '٤ ساعات',
    price: '٢٥$',
    description: 'استكشف الأسواق التاريخية، قلعة طرابلس، والمساجد الأثرية',
    highlights: ['قلعة طرابلس', 'الأسواق التقليدية', 'الجامع المنصوري', 'سوق الحلويات'],
    popular: false,
  },
  {
    title: 'جولة الطعام والحلويات',
    duration: '٣ ساعات',
    price: '٣٠$',
    description: 'رحلة لذيذة لتذوق أشهى المأكولات والحلويات الطرابلسية',
    highlights: ['محلات الحلويات', 'المطاعم التقليدية', 'سوق العطارين', 'تذوق البقلاوة'],
    popular: true,
  },
  {
    title: 'جولة شاملة',
    duration: 'يوم كامل',
    price: '٥٠$',
    description: 'جولة كاملة تشمل المعالم التاريخية والثقافية والطعام',
    highlights: ['جميع المعالم الرئيسية', 'غداء تقليدي', 'الميناء القديم', 'جزر النخيل'],
    popular: false,
  },
];

export function Booking() {
  const { isAuthenticated } = useAuth();
  const [date, setDate] = useState<Date>();
  const [tourType, setTourType] = useState('');
  const [groupSize, setGroupSize] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<number | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingSuccess(true);
    setTimeout(() => {
      setBookingSuccess(false);
      setDate(undefined); setTourType(''); setGroupSize('');
      setFullName(''); setEmail(''); setPhone(''); setNotes('');
      setSelectedPackage(null);
    }, 4000);
  };

  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-16 max-w-7xl mx-auto px-6 text-center">
        <motion.div {...fadeUp()}>
          <div className="text-primary text-sm font-medium tracking-widest mb-4">التخطيط لرحلتك</div>
          <h1 className="text-5xl md:text-7xl font-bold mb-6" style={{ fontFamily: "'El Messiri', serif" }}>
            احجز زيارتك
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            خطط لزيارتك القادمة إلى طرابلس واستمتع بتجربة لا تُنسى بصحبة مرشدنا المحترف
          </p>
        </motion.div>
      </section>

      {/* Tour Packages */}
      <section className="pb-16 border-b border-border">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div {...fadeUp()} className="mb-10">
            <div className="text-primary text-sm font-medium tracking-widest mb-3">اختر باقتك</div>
            <h2 className="text-4xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>باقات الجولات السياحية</h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-5">
            {tourPackages.map((pkg, i) => (
              <motion.div key={i} {...fadeUp(i * 0.1)}>
                <button
                  type="button"
                  onClick={() => setSelectedPackage(selectedPackage === i ? null : i)}
                  className={`w-full text-right bg-card rounded-2xl border-2 p-7 transition-all duration-300 group relative ${
                    selectedPackage === i
                      ? 'border-primary shadow-lg shadow-primary/15'
                      : 'border-border hover:border-primary/40'
                  }`}
                >
                  {pkg.popular && (
                    <div className="absolute top-4 left-4 text-xs px-3 py-1 bg-primary text-primary-foreground rounded-full font-medium">
                      الأكثر طلباً
                    </div>
                  )}
                  <div className="flex items-start justify-between mb-4 gap-2">
                    <div className="text-3xl font-bold text-primary" style={{ fontFamily: "'El Messiri', serif" }}>{pkg.price}</div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="w-3.5 h-3.5" />
                      {pkg.duration}
                    </div>
                  </div>
                  <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors" style={{ fontFamily: "'El Messiri', serif" }}>
                    {pkg.title}
                  </h3>
                  <p className="text-muted-foreground text-sm mb-5 leading-relaxed">{pkg.description}</p>
                  <ul className="space-y-2">
                    {pkg.highlights.map((h, j) => (
                      <li key={j} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />
                        {h}
                      </li>
                    ))}
                  </ul>
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Booking Form */}
      <section className="py-20 max-w-3xl mx-auto px-6">
        <motion.div {...fadeUp()}>
          {/* Auth notice */}
          {!isAuthenticated && (
            <div className="flex items-start gap-3 bg-card border border-border rounded-xl p-4 mb-8 text-sm">
              <AlertCircle className="w-4 h-4 text-primary shrink-0 mt-0.5" />
              <span className="text-muted-foreground">
                يُفضل{' '}
                <span className="text-primary font-medium cursor-pointer">تسجيل الدخول</span>
                {' '}لحفظ بيانات الحجز وتتبع طلباتك
              </span>
            </div>
          )}

          {/* Success */}
          {bookingSuccess && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex items-center gap-3 bg-emerald-900/30 border border-emerald-700/40 rounded-xl p-5 mb-8"
            >
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <div className="font-semibold text-emerald-300">تم إرسال طلب الحجز بنجاح!</div>
                <div className="text-sm text-emerald-400/70 mt-0.5">سنتواصل معك قريباً للتأكيد.</div>
              </div>
            </motion.div>
          )}

          <div className="bg-card border border-border rounded-3xl p-8 md:p-10">
            <div className="text-primary text-sm font-medium tracking-widest mb-3">نموذج الحجز</div>
            <h2 className="text-3xl font-bold mb-8" style={{ fontFamily: "'El Messiri', serif" }}>
              بياناتك الشخصية
            </h2>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <Label className="text-foreground text-sm font-medium">الاسم الكامل *</Label>
                  <Input value={fullName} onChange={(e) => setFullName(e.target.value)} required placeholder="أدخل اسمك الكامل" className="bg-secondary border-border text-foreground placeholder:text-muted-foreground focus:border-primary" />
                </div>
                <div className="space-y-2">
                  <Label className="text-foreground text-sm font-medium">البريد الإلكتروني *</Label>
                  <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required placeholder="example@email.com" className="bg-secondary border-border text-foreground placeholder:text-muted-foreground focus:border-primary" />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-foreground text-sm font-medium">رقم الهاتف *</Label>
                <Input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required placeholder="+961 XX XXX XXX" className="bg-secondary border-border text-foreground placeholder:text-muted-foreground focus:border-primary" />
              </div>

              <div className="grid md:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <Label className="text-foreground text-sm font-medium">تاريخ الزيارة *</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <button
                        type="button"
                        className="w-full flex items-center justify-between px-4 py-2.5 bg-secondary border border-border rounded-lg text-sm hover:border-primary transition-colors"
                      >
                        <span className={date ? 'text-foreground' : 'text-muted-foreground'}>
                          {date ? format(date, 'PPP', { locale: ar }) : 'اختر التاريخ'}
                        </span>
                        <CalendarIcon className="w-4 h-4 text-muted-foreground" />
                      </button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                      <Calendar mode="single" selected={date} onSelect={setDate} disabled={(d) => d < new Date()} initialFocus className="bg-card text-foreground" />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label className="text-foreground text-sm font-medium">نوع الجولة *</Label>
                  <Select value={tourType} onValueChange={setTourType} required>
                    <SelectTrigger className="bg-secondary border-border text-foreground">
                      <SelectValue placeholder="اختر نوع الجولة" />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border text-foreground">
                      <SelectItem value="old-city">جولة المدينة القديمة</SelectItem>
                      <SelectItem value="food">جولة الطعام والحلويات</SelectItem>
                      <SelectItem value="full">جولة شاملة</SelectItem>
                      <SelectItem value="custom">جولة مخصصة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-foreground text-sm font-medium">عدد الأشخاص *</Label>
                <Select value={groupSize} onValueChange={setGroupSize} required>
                  <SelectTrigger className="bg-secondary border-border text-foreground">
                    <SelectValue placeholder="اختر عدد الأشخاص" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border text-foreground">
                    <SelectItem value="1">شخص واحد</SelectItem>
                    <SelectItem value="2">شخصان</SelectItem>
                    <SelectItem value="3-5">٣ - ٥ أشخاص</SelectItem>
                    <SelectItem value="6-10">٦ - ١٠ أشخاص</SelectItem>
                    <SelectItem value="10+">أكثر من ١٠ أشخاص</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-foreground text-sm font-medium">ملاحظات إضافية</Label>
                <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="أي طلبات أو ملاحظات خاصة..." rows={4} className="bg-secondary border-border text-foreground placeholder:text-muted-foreground focus:border-primary resize-none" />
              </div>

              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full py-4 bg-primary text-primary-foreground font-bold rounded-xl text-lg hover:opacity-90 transition-all shadow-lg shadow-primary/25"
              >
                إرسال طلب الحجز
              </motion.button>
            </form>
          </div>
        </motion.div>
      </section>

      {/* Contact */}
      <section className="pb-20 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div {...fadeUp()} className="grid md:grid-cols-3 gap-5">
            {[
              { icon: MapPin, title: 'العنوان', lines: ['طرابلس، لبنان', 'المدينة القديمة'] },
              { icon: Users, title: 'الهاتف', lines: ['+961 6 XXX XXX', 'يومياً ٩:٠٠ ص - ٦:٠٠ م'] },
              { icon: Clock, title: 'ساعات العمل', lines: ['السبت - الخميس', '٩:٠٠ ص - ٦:٠٠ م'] },
            ].map((c, i) => {
              const Icon = c.icon;
              return (
                <div key={i} className="bg-card border border-border rounded-2xl p-7 text-center hover:border-primary/40 transition-all duration-300">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <h3 className="font-bold text-lg mb-2" style={{ fontFamily: "'El Messiri', serif" }}>{c.title}</h3>
                  {c.lines.map((l, j) => (
                    <p key={j} className={j === 0 ? 'text-foreground' : 'text-xs text-muted-foreground mt-1'}>{l}</p>
                  ))}
                </div>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* Tips */}
      <section className="py-16 border-t border-border">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div {...fadeUp()} className="mb-10">
            <div className="text-primary text-sm font-medium tracking-widest mb-3">استعد جيداً</div>
            <h2 className="text-4xl font-bold" style={{ fontFamily: "'El Messiri', serif" }}>نصائح قبل الزيارة</h2>
          </motion.div>
          <div className="grid md:grid-cols-2 gap-5">
            {[
              { title: 'ملابس مريحة', text: 'احرص على ارتداء أحذية مريحة للمشي في الأزقة القديمة' },
              { title: 'كاميرا', text: 'لا تنسَ كاميرتك لالتقاط صور رائعة للمعالم التاريخية' },
              { title: 'الحجز المسبق', text: 'يُفضل الحجز قبل 3 أيام على الأقل لضمان التوفر' },
              { title: 'مرشد سياحي', text: 'جميع الجولات تشمل مرشداً سياحياً محترفاً باللغة العربية' },
            ].map((tip, i) => (
              <motion.div key={i} {...fadeUp(i * 0.08)}>
                <div className="flex items-start gap-4 bg-card border border-border rounded-xl p-6 hover:border-primary/40 transition-all duration-300">
                  <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold mb-1" style={{ fontFamily: "'El Messiri', serif" }}>{tip.title}</h3>
                    <p className="text-muted-foreground text-sm">{tip.text}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
